# My Package

A simple example package.

## Installation

Details here lol. 