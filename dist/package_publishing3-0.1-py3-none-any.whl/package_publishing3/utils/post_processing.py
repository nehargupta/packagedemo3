from .. import module1

def what(modelobj):
    if modelobj.add:
        return "add"
    if modelobj.sub:
        return "sub"
